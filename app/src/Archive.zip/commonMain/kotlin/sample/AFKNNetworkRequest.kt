package sample

import io.ktor.client.HttpClient
import io.ktor.client.call.call
import io.ktor.client.call.receive
import io.ktor.client.features.DefaultRequest.Feature.install
import io.ktor.client.request.*
import io.ktor.client.response.readBytes
import io.ktor.client.response.readText
import io.ktor.http.Headers
import io.ktor.http.HttpMessageBuilder
import io.ktor.http.HttpMethod
import io.ktor.http.URLBuilder
import io.ktor.util.Hash
import io.ktor.http.*
import kotlinx.coroutines.*


data class DCNetworkRequestHeader(
    var authKey: String = "",
    var iso_code: String = "",
    var apiVersion: String = "",
    var appVersion: String = "",
    var lang: String = "",
    var deviceType: String = "android",
    var tokenId: String = "",
    var authToken: String = "",
    var udid: String = ""
)

class AFKNBaseRequest {

    enum class RequestType {
        NEW, OLD
    }

    var HEADER_DATA: HashMap<String, Any>? = HashMap()
    private var COMMON_PARAMS: HashMap<String, Any>? = HashMap()
    private var RESPONCE_FORMAT: AFKNResponceFormat? = AFKNResponceFormat()
    var BASE_URL: String = "";

    companion object {
        fun getBaseRequest(type: RequestType): AFKNBaseRequest {
            var model = AFKNBaseRequest()

            when (type) {
                RequestType.NEW -> {
                    model.BASE_URL = "http://dapi.docquity.com"
                    model.HEADER_DATA?.put("Authorization", "Basic SDJPSDJTTzRPT0hDSDRIMk8yOg==")
                    model.HEADER_DATA?.put("lang", "en")
                    model.HEADER_DATA?.put("ver", "4.0")
                    model.HEADER_DATA?.put("appversion", "87")
                    model.HEADER_DATA?.put("devicetype", "android")
                    model.HEADER_DATA?.put("userauthkey", "d64726112c82f3a8b7187a7610750036")
                    model.HEADER_DATA?.put("udid", "pawanRequest")

                }

                RequestType.OLD -> {

                }
            }

            return model
        }
    }



}

class AFKNResponceFormat {

    var parentKey: String = ""
    var statussMsgKey: String = "msg"
    var statusCodeKey: String = "status"
    var successCodeKey: String = "code"
    var dataKey: String = "data"
    var errorObjectKey: String = "error"
    var sucessCodeValue: Int = 1
    var sucessCodeValueArray: List<Int> = listOf(1)


}


internal expect val ApplicationDispatcher: CoroutineDispatcher

class AFKNNetworkRequest {



    enum class AFKNNetworkRequestType {
        GET,
        POST,
        DELETE,
        MULTIPART,
        PUT
    };

    lateinit var BASE_REQUEST: AFKNBaseRequest;
    var PARAMS: HashMap<String, Any?> = hashMapOf()
    var API_URL: String = "";
    var REQUEST_TYPE: AFKNNetworkRequestType = AFKNNetworkRequestType.GET
    var RESPONCE_FORMAT:AFKNResponceFormat = AFKNResponceFormat();


    fun getRequestType(): HttpMethod {

        var methord: HttpMethod = HttpMethod.Get

        when (this.REQUEST_TYPE) {

            AFKNNetworkRequestType.GET -> methord = HttpMethod.Get
            AFKNNetworkRequestType.POST -> methord = HttpMethod.Post
            AFKNNetworkRequestType.DELETE -> methord = HttpMethod.Delete
            AFKNNetworkRequestType.PUT -> methord = HttpMethod.Put
            AFKNNetworkRequestType.MULTIPART -> methord = HttpMethod.Post

        }

        return methord;

    }


    fun makeReuest(complition:(response:AFKNNetworkResponse)->Int) {


        GlobalScope.apply {
            launch(ApplicationDispatcher) {

                sequentialRequests(complition = {
                    complition(it);
                    return@sequentialRequests 1;
                })

            }
        }
        return;

        GlobalScope.launch {

            var resc:AFKNNetworkResponse = AFKNNetworkResponse()
            resc.RESPONCE_SUCCESS_MSG = "Before Calling"
                withContext(Dispatchers.Default){
                    complition(resc)
            }



        }
      return;

        GlobalScope.async {
            sequentialRequests(complition = {
                complition(it);
                return@sequentialRequests 1;
            })
        }


    }




   suspend fun sequentialRequests(complition:(response:AFKNNetworkResponse)->Int) {




       val client = HttpClient()



       var currentObj = this

       val call = client.call(currentObj.BASE_REQUEST.BASE_URL + currentObj.API_URL) {
           method = currentObj.getRequestType()
          // contentType(ContentType.Application.Json)
           for ((key, value) in currentObj.BASE_REQUEST.HEADER_DATA?.iterator()!!) {
               headers.append(key, value as String)
           }
           for ((key, value) in currentObj.PARAMS?.iterator()!!) {
               parameter(key, value)
           }
           println("API Request" + client.attributes)

       }

       var responce = call.response;


      /* var response:AFKNNetworkResponse = AFKNNetworkResponse();
       response.RESPONCE_SUCCESS_MSG = call.response.readText();
       complition(response)*/

      // call.receive<Any>()
       var dataHashMap = AFKNPlatformUtil().getHashMapFromJsonString(call.response.readText());
       println("=======" + dataHashMap);

       var response = AFKNNetworkResponse.parseHashMapForResponce(this,dataHashMap);
       complition(response);
       println("=======" + response);


   }



}

