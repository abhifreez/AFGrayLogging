package sample




/*
public enum actionType:String{

    case alert = "alert"
    case silent = "silent"
    case nofification = "nofification"
    case navigate = "navigate"
    case none = "none"

    static func parse(type:String) -> actionType {
        switch type {

            case "alert" : return .alert
            case "silent" : return .silent
            case "nofification" : return .nofification
            case "navigate" : return .navigate

            default: return .none
        }
    }

}*/

 class AFKNNetworkResponse {

     var RESPONCE_STATUS_CODE:Int = 0;
     var RESPONCE_SUCCESS_MSG:String = "";
     var IS_SUCCESS:Int = 0;
     var ERROR:AFKNError?=null ;
     var RESPONCE_DATA:Any? = null
     // var RESPONCE_RAW_DATA:?=null
     // var RESPONCE_ACTION:DCNFAction?=nil;



     companion object {

       fun  parseHashMapForResponce(request:AFKNNetworkRequest,data:Map<String,Any>):AFKNNetworkResponse{



           print("============1")
           var response:AFKNNetworkResponse = AFKNNetworkResponse()
           var responseFormat = request.RESPONCE_FORMAT
          // response.IS_SUCCESS = data.get(responseFormat.statusCodeKey) as Int;
           response.RESPONCE_DATA = data.get(responseFormat.dataKey);

           print("============1")
           return  response;

           //response.IS_SUCCESS = data.get(request.BASE_REQUEST.re)

         }
     }


}

 class AFKNError {

     var ERROR_CODE:Int = 0
     var ERROR_MESSAGE:String? = ""
     var ERROR_DATA:Any? = null

}



/*
public class DCNFAction : NSObject{

    public var TYPE: actionType?
    public var PARAM: Array<DCNFParam>?
    public var PROCESS: Array<DCNFProcess>?
}*/

/*
public class DCNFParam : NSObject{

    public var KEY: String?
    public var VALUE: String?

}*/

/*
public class DCNFTarget: NSObject{

    public var TYPE: String?
    public var ID: String?
    public var URL: String?
}*/

/*
public class DCNFProcess: NSObject{

    public var TYPE: String?
    public var TARGET: Array<DCNFTarget>?
    public var PARAM: Array<DCNFParam>?
}
*/
