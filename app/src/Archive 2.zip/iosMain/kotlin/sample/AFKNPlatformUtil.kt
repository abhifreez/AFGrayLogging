package sample

import kotlinx.wasm.jsinterop.Object
import platform.Foundation.*







actual class AFKNPlatformUtil actual constructor() {

    actual fun getHashMapFromJsonString(string: String): Map<String, Any>{


       // return hashMapOf("xx" to "yy")

       var stringData = (string as? NSString)?.dataUsingEncoding(NSUTF8StringEncoding)

        //var error = NSError()
       var dict : NSDictionary = NSJSONSerialization.JSONObjectWithData(stringData as NSData,NSJSONReadingMutableContainers,null) as NSDictionary;
        return  getMapFormDict(dict);



    }

    fun getMapFormDict(dict:NSDictionary):Map<String,Any>{


        var keys = dict.allKeys()
        var map = mutableMapOf<String,Any>()

        for (key in keys){

            var value = dict.objectForKey(key)
            if(value is NSDictionary) {
                map.put((key as String), getMapFormDict(value))
            }

            map.put((key as String),dict.objectForKey(key) as Any)


        }
        return map;

    }



}