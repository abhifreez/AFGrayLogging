package sample

actual class DCBroadcastUtils actual constructor() {
    actual fun sendBroadcast(context: Any?, intentType: String?, broadcastKey: Int?, broadcastValue: Any?, forId: Int?) {
    }
}