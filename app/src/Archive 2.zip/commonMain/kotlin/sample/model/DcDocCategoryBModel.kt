package sample.model

import sample.AFKNBaseRequest
import sample.AFKNConstant
import sample.AFKNNetworkRequest
import sample.DcDocTalkBModel

class DcDocCategoryBModel {
    var categoryTitle: String? = ""
    var categoryId: Int? = 0
    var dataList: ArrayList<Any>? = ArrayList()
    var categoryType: String? = ""

    fun getList(block: (ArrayList<DcDocCategoryBModel>) -> Unit) {
        var params = HashMap<String, Any?>()
        var request = AFKNNetworkRequest()
        var baseRequest = AFKNBaseRequest.getBaseRequest(AFKNBaseRequest.RequestType.NEW)
        request.BASE_REQUEST = baseRequest
        request.REQUEST_TYPE = AFKNNetworkRequest.AFKNNetworkRequestType.GET
        request.API_URL = AFKNConstant.DOC_TALK_LIST
        request.PARAMS = params

        request.makeRequest {
            var code = it.IS_SUCCESS
            var listData: ArrayList<DcDocCategoryBModel> = ArrayList()
            if (code == 1) {
                var dataList = (it.RESPONCE_DATA as ArrayList<Map<String, Any>>)

                for (data in dataList) {
                    var docCategory = DcDocCategoryBModel()
                    docCategory.categoryType = data.get("section_key") as String
                    docCategory.categoryTitle = data.get("section_name") as String

                    var itemsList = data.get("list") as ArrayList<Map<String, Any>>
                    when (docCategory.categoryType) {
                        AFKNConstant.DOC_CATEGORY_TYPE_BANNER -> {
                            docCategory.dataList = parseBannerList(itemsList) as ArrayList<Any>
                        }
                        AFKNConstant.DOC_CATEGORY_TYPE_FEATURES_VIDEOS -> {
                            docCategory.dataList = parseVideoList(itemsList) as ArrayList<Any>
                        }
                        AFKNConstant.DOC_CATEGORY_TYPE_SPECIALITY -> {
                            docCategory.dataList = parseSpecialityList(itemsList) as ArrayList<Any>
                        }
                        AFKNConstant.DOC_CATEGORY_TYPE_TOP_SPEAKERS -> {
                            docCategory.dataList = parseSpeakerList(itemsList) as ArrayList<Any>
                        }
                        else ->{
                            docCategory.dataList = parseVideoList(itemsList) as ArrayList<Any>
                        }
                    }
                    listData.add(docCategory)
                }
            }
            block(listData)
            return@makeRequest 1
        }
    }

    private fun parseBannerList(dataList: ArrayList<Map<String, Any>>): ArrayList<DCBannerBModel> {
        var list = ArrayList<DCBannerBModel>()
        for (data in dataList) {
            var banner = DCBannerBModel(data)
            list.add(banner)
        }
        return list
    }

    private fun parseVideoList(dataList: ArrayList<Map<String, Any>>): ArrayList<DcDocTalkBModel> {
        var list = ArrayList<DcDocTalkBModel>()
        for (data in dataList) {
            var video = DcDocTalkBModel()
//            banner.fextraId = data.get("fextra_id") as Int
//            video.title = data.get("title") as String
////            banner.fileType = data.get("file_type") as String
////            banner.fileUrl = data.get("file_url") as String
////            banner.classification = data.get("classification") as String
////            banner.targetId = data.get("target_id") as Int
//            video.type = data.get("type") as String
            list.add(video)
        }
        return list
    }

    private fun parseSpeakerList(dataList: ArrayList<Map<String, Any>>): ArrayList<DCSpeakerBModel> {
        var list = ArrayList<DCSpeakerBModel>()
        for (data in dataList) {
            var speaker = DCSpeakerBModel(data)
            list.add(speaker)
        }
        return list
    }

    private fun parseSpecialityList(dataList: ArrayList<Map<String, Any>>): ArrayList<AFKNSpecialityBModel> {
        var list = ArrayList<AFKNSpecialityBModel>()
        for (data in dataList) {
            var speciality = AFKNSpecialityBModel(data)
            list.add(speciality)
        }
        return list
    }
}