package sample.model

class DCKNUserInfo {

    var lang: String? = ""
    var authorization: String? = ""
    var userAuthKey: String? = ""
}