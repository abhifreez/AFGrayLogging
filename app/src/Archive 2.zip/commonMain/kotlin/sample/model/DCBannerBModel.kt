package sample.model


class DCBannerBModel(val data: Map<String, Any>?) {
    var fextraId = data?.get("fextra_id") as Int
    var title = data?.get("title") as String
    var content: String? = null
    var fileType = data?.get("file_type") as String
    var fileUrl = data?.get("file_url") as String
    var dateOfCreation: Long = 0
    var dateOfUpdation: Long = 0
    var classification = data?.get("classification") as String
    var targetId = data?.get("target_id") as Int
    var target_url: String? = null
    var type = data?.get("type") as String
    var typeId: Int? = null
    var position: Int? = null
    var pageNo: Int? = null
}