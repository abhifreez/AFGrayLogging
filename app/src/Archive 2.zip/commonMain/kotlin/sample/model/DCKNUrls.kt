package sample.model

class DCKNUrls {
    var baseUrl: String? = ""
}