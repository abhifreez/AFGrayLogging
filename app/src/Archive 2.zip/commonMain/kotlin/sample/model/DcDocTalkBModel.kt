package sample

import sample.model.AFKNMediaBModel
import sample.model.AFKNShareBModel
import sample.model.DCSpeakerBModel
import sample.model.DKDTSeries
import kotlin.collections.ArrayList



class DcDocTalkBModel {

    var id: Int = 0
    var title: String = ""
    var description: String = ""
    var publishData:Long = 0
    var commentFlag:Boolean = true
    var episodeIndex:Int = 0
    var speakerList: ArrayList<DCSpeakerBModel>? = ArrayList()
    var series: DKDTSeries? = null
    var isSeries:Boolean = false
    var likeCount:Int = 0
    var viewsCount:Int = 0
    var isLiked:Boolean = false
    var isBookmarked:Boolean = false;
    var mediaList: ArrayList<AFKNMediaBModel>? = ArrayList()
    var shareData: AFKNShareBModel? = null
    





   fun DcDocTalkBModel(jsonDict:Map<Any,Any>): DcDocTalkBModel {


        var obj:DcDocTalkBModel = DcDocTalkBModel()
        obj.id = jsonDict?.get("name") as Int
        obj.title = jsonDict?.get("title") as String
        obj.description = jsonDict?.get("description") as String
        obj.publishData = jsonDict?.get("publish_date") as Long
        obj.commentFlag = jsonDict?.get("comment_flag") as Boolean
        obj.episodeIndex = jsonDict?.get("episode_index") as Int
        obj.speakerList = DCSpeakerBModel.parseSpeakerList(dataList = jsonDict?.get("speaker") as ArrayList<Map<String, Any>>)
        obj.series = DKDTSeries(jsonDict = jsonDict?.get("series") as Map<String, Any>)
        obj.isSeries = jsonDict?.get("is_series") as Boolean
        obj.isLiked = jsonDict?.get("is_liked") as Boolean
        obj.isBookmarked = jsonDict?.get("is_bookmarks") as Boolean
       // obj.mediaList = AFKNMediaBModel.parseMediaList(dataList = jsonDict?.get("media") as ArrayList<Map<String, Any>>)

        return obj;
   }


    
    
    



   
    
  

  
   
    
    
    

  

   

    /*
    "doctalks_id": 5,
                "title": "Radiology specialtiy Doctor",
                "description": "Cardiology Details",
                "summary": "Description about Cardiology",
                "publish_date": 1555059438,
                "end_date": 1555959438, ==
                "comment_flag": "1",
                "association_id": 3, ==
                "institution_name": "Team Docquity", ==
                "association_pic_path": "http://devbucket.docquity.com/random_file/image/file_1509014040docquity59f1ba186fc0e.jpeg", ==
                "country": "India", ==
                "institution_number": "docquity",==
                "doctalks_banner": "https://cdn.pixabay.com/photo/2015/11/02/18/34/banner-1018818_1280.jpg", ==
                "episode_index": 2,
                "speaker": [
                    {
                        "name": "pawan nagar",
                        "profile_pic": "https://scontent.fdel21-1.fna.fbcdn.net/v/t1.0-9/13445786_273827899635283_4302446987675838602_n.jpg?_nc_cat=106&_nc_ht=scontent.fdel21-1.fna&oh=3555cef1c3d86fb787f13a610494d4a3&oe=5D45A774",
                        "synopsis": "dslkfjslkd",
                        "qualification": "Phd"
                    }
                ],
                "series": {
                    "doctalks_series_id": 26,
                    "doctalk_series_title": "Series 26",
                    "doctalks_description": "series one",
                    "doctalks_banner": "series one"
                },
                "in_series": true,
                "like": 8,
                "views": 4,
                "is_views": 0,
                "is_bookmarks": 0,
                "bookmarks": 6,
                "media": [],
                "share": {
                    "email_title": "Your Colleague Pawan Nagar needs your opinion",
                    "email_content": "Hi,<br/><br/>Sharing with you some recent article on Docquity. The fastest growing private & secure continual learning network for doctors. <br/><br/><a> http://dev.docquity.com/feed/1.1556082453/R5c3c307ea2e0e </a><br/><br/>Looking to connect with you here on Docquity<br/><br/>Thanks<br/><br/>Pawan Nagar<br/>",
                    "other_content": "Check out this video from Docquity - the medical learning app. Like, Comment & Share.Click here http://dev.docquity.com/feed/1.1556082453/R5c3c307ea2e0e"
                }
     */


//
//    fun getDetails(block: (DcDocTalkBModel) -> Unit) {
//        var params = HashMap<String, Any?>()
//        params.put("doctalks_id", 4)
//
//        var request = AFKNNetworkRequest()
//        var baseRequest = AFKNBaseRequest.getBaseRequest(AFKNBaseRequest.RequestType.NEW)
//        request.BASE_REQUEST = baseRequest
//        request.API_URL = "/4.0/cme/detail?"
//        request.PARAMS = params
//
//        request.makeRequest {
//            var docTlk: DcDocTalkBModel = DcDocTalkBModel()
//           // docTlk.type = ((it.RESPONCE_DATA as Map<String, Any>).get("doctalks") as Map<String, Any>).get("course_name")
//            //it.RESPONCE_DATA.toString()
//
//            block(docTlk)
//            return@makeRequest 1
//        }
//    }

    fun bookmark(block: (Boolean) -> Unit) {
        var bookmarkNewValue = isBookmarked?.not()
        var params = HashMap<String, Any?>()
        params.put("product_type", "docktalk")
        params.put("product_type_id", id)
        params.put("action", bookmarkNewValue)

        var request = AFKNNetworkRequest()
        var baseRequest = AFKNBaseRequest.getBaseRequest(AFKNBaseRequest.RequestType.NEW)
        request.REQUEST_TYPE=AFKNNetworkRequest.AFKNNetworkRequestType.POST
        request.BASE_REQUEST = baseRequest
        request.API_URL = AFKNConstant.ADD_BOOKMARK
        request.PARAMS = params


        request.makeRequest {
            var code = it.IS_SUCCESS

            if (code == 1)
                block(bookmarkNewValue!!)
            else
                block(bookmarkNewValue?.not()!!)
            return@makeRequest 1
        }
    }

    fun like(block: (Boolean) -> Unit) {
        var params = HashMap<String, Any?>()
        params.put("product_type", "docktalk")
        params.put("product_type_id", id)
        params.put("action", "like")

        var request = AFKNNetworkRequest()
        var baseRequest = AFKNBaseRequest.getBaseRequest(AFKNBaseRequest.RequestType.NEW)
        request.BASE_REQUEST = baseRequest
        request.REQUEST_TYPE=AFKNNetworkRequest.AFKNNetworkRequestType.POST
        request.API_URL = AFKNConstant.POST_LIKE
        request.PARAMS = params


        request.makeRequest {
            var code = it.IS_SUCCESS
            if (code == 1)
                block(true)
            else
                block(false)
            return@makeRequest 1
        }
    }

    fun getDoctalkDetail(id:Int){

        var params = HashMap<String, Any?>()
        params.put("doctalks_id", id)


        var request = AFKNNetworkRequest()
        var baseRequest = AFKNBaseRequest.getBaseRequest(AFKNBaseRequest.RequestType.NEW)
        request.BASE_REQUEST = baseRequest
        request.REQUEST_TYPE=AFKNNetworkRequest.AFKNNetworkRequestType.GET
        request.API_URL = AFKNConstant.POST_LIKE
        request.PARAMS = params

        request.makeRequest { response:AFKNNetworkResponse ->





            return@makeRequest 0;
        }



    }
}