package sample.model

import sample.AFKNNetworkRequest

class DKLocation {



    companion object {
        fun getAddressForCordinates(cordinates:DKLCordinates,complition:(address:DKLAddress)->Int) {


            complition(DKLAddress());
            return;

            var url = "https://maps.googleapis.com/maps/api/geocode/json?latlng="+cordinates.latitude+","+cordinates.logitude+"&key=AIzaSyC4PtVTJCYWSRuCkXChpku1unvN5MH-SXc"
            var request = AFKNNetworkRequest();



            request.thirdPartyRequest(url = url,data = "",compilation = {

                var address = DKLAddress(it.RESPONCE_DATA as HashMap<Any, Any>);
                complition(address)

                return@thirdPartyRequest 0;
            })


        }
    }

}

class  DKLCordinates(latitude:Double,longitude:Double){


    var latitude:Double = latitude
    var logitude:Double = longitude
}

class  DKLAddress{

    var country:String = ""
    var city:String = ""
    var state:String = ""
    var postalCode:String = ""
    var fullAddress:String = ""

    constructor(){

    }

    constructor(data:HashMap<Any,Any>){


        var results:ArrayList<Any> = data["results"] as ArrayList<Any>
        var result:HashMap<String,Any> = results[0] as HashMap<String,Any>;
        var addressComponents:ArrayList<Any> = result["address_components"] as ArrayList<Any>;
        fullAddress = result["formatted_address"] as String;

        for (component in addressComponents){

            var comp:HashMap<String,Any> = component as HashMap<String, Any>;
            var types:ArrayList<String> = comp["types"] as ArrayList<String>;

            if (types.contains("administrative_area_level_2")) {

                city = comp["long_name"] as String

            }
            else if (types.contains("administrative_area_level_1")) {

                state = comp["long_name"] as String

            }
            else if (types.contains("country")) {

                country = comp["long_name"] as String

            }



        }





    }





}