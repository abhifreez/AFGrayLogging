package sample.model

class DCKNDeviceInfo {
    var apiVersion: String? = ""
    var appVersion: String? = ""
    var deviceType: String? = ""
    var udid: String? = ""
}